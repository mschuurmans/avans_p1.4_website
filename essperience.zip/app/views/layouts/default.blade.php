<html>
 <title>{{$title}}</title>
 <body>
  @yield('header')
  @yield('content')
  @yield('footer')
 </body>
</html>
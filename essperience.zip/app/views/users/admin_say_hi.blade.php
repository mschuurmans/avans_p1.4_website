<html>
dit is een admin view. met id: {{$id}}
</html>

<html>
dit is een view. met id: {{$id}}
</html>

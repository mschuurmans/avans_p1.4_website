@extends('layouts.default')
@section('header')
  header here <br /> 
@endsection
@section('footer')
  footer
@endsection
@section('content')
  content
@endsection